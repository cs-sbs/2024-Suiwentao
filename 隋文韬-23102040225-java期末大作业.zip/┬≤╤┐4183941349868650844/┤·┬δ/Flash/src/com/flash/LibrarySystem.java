package com.flash;

import com.flash.dao.BookDAO;
import com.flash.dao.UserDAO;
import com.flash.pojo.Book;
import com.flash.pojo.User;
import com.flash.utils.DatabaseUtil;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;

/**
 * 主程序，控制台图书管理系统入口。
 */
public class LibrarySystem {
    public static void main(String[] args) {
        try (Connection connection = DatabaseUtil.getConnection()) {
            UserDAO userDAO = new UserDAO(connection);
            BookDAO bookDAO = new BookDAO(connection);
            Scanner scanner = new Scanner(System.in);

            System.out.println("欢迎进入图书管理系统！");
            while (true) {
                System.out.println("请输入操作 (register/login/exit): ");
                String command = scanner.nextLine();
                if ("register".equalsIgnoreCase(command)) {
                    System.out.println("输入用户名: ");
                    String username = scanner.nextLine();
                    System.out.println("输入密码: ");
                    String password = scanner.nextLine();
                    System.out.println("输入角色 (admin/user): ");
                    String role = scanner.nextLine();
                    userDAO.registerUser(new User(username, password, role));
                    System.out.println("注册成功！");
                } else if ("login".equalsIgnoreCase(command)) {
                    System.out.println("输入用户名: ");
                    String username = scanner.nextLine();
                    System.out.println("输入密码: ");
                    String password = scanner.nextLine();
                    User user = userDAO.loginUser(username, password);
                    if (user != null) {
                        System.out.println("登录成功，角色: " + user.getRole());
                        if ("admin".equalsIgnoreCase(user.getRole())) {
                            adminMenu(bookDAO, scanner);
                        } else {
                            userMenu(bookDAO, scanner);
                        }
                    } else {
                        System.out.println("登录失败，用户名或密码错误！");
                    }
                } else if ("exit".equalsIgnoreCase(command)) {
                    System.out.println("退出系统！");
                    break;
                } else {
                    System.out.println("无效命令！");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void adminMenu(BookDAO bookDAO, Scanner scanner) throws SQLException {
        while (true) {
            System.out.println("管理员菜单：");
            System.out.println("1. 添加图书");
            System.out.println("2. 删除图书");
            System.out.println("3. 查看所有图书");
            System.out.println("4. 退出");
            int choice = Integer.parseInt(scanner.nextLine());
            switch (choice) {
                case 1:
                    System.out.println("输入书名: ");
                    String title = scanner.nextLine();
                    System.out.println("输入作者: ");
                    String author = scanner.nextLine();
                    System.out.println("输入ISBN: ");
                    String isbn = scanner.nextLine();
                    System.out.println("输入分类: ");
                    String category = scanner.nextLine();
                    System.out.println("输入出版日期 (yyyy-MM-dd): ");
                    String publishDate = scanner.nextLine();
                    bookDAO.addBook(new Book(0, title, author, isbn, category, publishDate));
                    System.out.println("图书添加成功！");
                    break;
                case 2:
                    System.out.println("输入要删除的图书ID: ");
                    int id = Integer.parseInt(scanner.nextLine());
                    if (bookDAO.deleteBook(id)) {
                        System.out.println("图书删除成功！");
                    } else {
                        System.out.println("删除失败，未找到该ID的图书！");
                    }
                    break;
                case 3:
                    System.out.println("所有图书列表：");
                    for (Book book : bookDAO.getAllBooks()) {
                        book.display();
                    }
                    break;
                case 4:
                    return;
                default:
                    System.out.println("无效选项！");
            }
        }
    }

    private static void userMenu(BookDAO bookDAO, Scanner scanner) throws SQLException {
        while (true) {
            System.out.println("普通用户菜单：");
            System.out.println("1. 查看所有图书");
            System.out.println("2. 按分类查看图书");
            System.out.println("3. 退出");
            int choice = Integer.parseInt(scanner.nextLine());
            switch (choice) {
                case 1:
                    System.out.println("所有图书列表：");
                    for (Book book : bookDAO.getAllBooks()) {
                        book.display();
                    }
                    break;
                case 2:
                    System.out.println("输入分类: ");
                    String category = scanner.nextLine();
                    System.out.println("分类 " + category + " 的图书列表：");
                    for (Book book : bookDAO.getBooksByCategory(category)) {
                        book.display();
                    }
                    break;
                case 3:
                    return;
                default:
                    System.out.println("无效选项！");
            }
        }
    }
}
