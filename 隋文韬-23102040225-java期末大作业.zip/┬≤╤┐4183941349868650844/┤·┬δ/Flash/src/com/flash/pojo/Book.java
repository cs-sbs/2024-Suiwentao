package com.flash.pojo;

public class Book {
    private int id;
    private String title;
    private String author;
    private String isbn;
    private String category;
    private String publishDate;

    public Book(int id, String title, String author, String isbn, String category, String publishDate) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.isbn = isbn;
        this.category = category;
        this.publishDate = publishDate;
    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public String getIsbn() {
        return isbn;
    }

    public String getCategory() {
        return category;
    }

    public String getPublishDate() {
        return publishDate;
    }

    public void display() {
        System.out.println("ID: " + id + ", 书名: " + title + ", 作者: " + author +
                ", ISBN: " + isbn + ", 分类: " + category + ", 出版日期: " + publishDate);
    }
}
